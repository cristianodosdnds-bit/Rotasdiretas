-- Rode este script no HeidiSQL (ou outro cliente MySQL) para criar o banco e a tabela inicial.

CREATE DATABASE IF NOT EXISTS rotas_expressas
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE rotas_expressas;

-- Tabela de usuários (motoristas/operadores que fazem login no app)
CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  senha_hash VARCHAR(255) NOT NULL,
  base_endereco VARCHAR(255) NULL,
  base_lat DECIMAL(10, 7) NULL,
  base_lng DECIMAL(10, 7) NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Tabela de paradas/entregas (cada linha é uma entrega de um usuário)
CREATE TABLE IF NOT EXISTS paradas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL,
  nome_cliente VARCHAR(150) NOT NULL,
  endereco VARCHAR(255) NOT NULL,
  bairro VARCHAR(120) NULL,
  cidade VARCHAR(120) NULL,
  lat DECIMAL(10, 7) NULL,
  lng DECIMAL(10, 7) NULL,
  observacao TEXT NULL,
  status ENUM('pendente', 'entregue', 'problema') NOT NULL DEFAULT 'pendente',
  motivo_problema VARCHAR(255) NULL,
  ordem_rota INT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;
